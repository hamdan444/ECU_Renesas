/*
 * CurrentSens.h
 *
 *  Created on: 06-Mar-2023
 *      Author: Admin
 */

#ifndef CURRENTSENS_H_
#define CURRENTSENS_H_

#include "hal_data.h"
#include "atCmd.h"

#define I_RX_BUF_SIZE               30


typedef struct
{
    volatile uint8_t rxBuf[I_RX_BUF_SIZE];
    volatile uint8_t rxbyte;
    volatile uint8_t rxCnt;
    volatile Bool_E rxFlag;

}CurrentSensor_Handle_S;



extern CurrentSensor_Handle_S IsenS;
extern bool Current_IS;
void Gpio_InputCheck(void);
void CurrentSense_rxCallback(uint8_t rxByte);
void CurrentSense_RxFrameHandle(void);


#endif /* CURRENTSENS_H_ */
