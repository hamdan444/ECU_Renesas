/*
 * atCmd.h
 *
 *  Created on: Dec 09, 2021
 *      Author: yoganathan.v
 */

/* Define to prevent recursive inclusion -----------------------------*/
#ifndef INC_ATCMD_H_
#define INC_ATCMD_H_

#ifdef __cplusplus
extern "C" {
#endif


/* Includes ----------------------------------------------------------*/

#include "hal_data.h"

/* Define ------------------------------------------------------------*/
#define GSM_TIMEOUT				    3000
#define GSM_NTWK_TIMEOUT			7000
#define GSM_REBOOT_TIMEOUT			10000

#define GSM_GPS_TIMEOUT             1100

#define GSM_MQTT_RES_WAITTIME       100

/* Macro -------------------------------------------------------------*/
#define RX_BUF_SIZE				    300
#define GPS_BUF_SIZE                150
#define MQTT_BUF_SIZE				1024
#define MQTT_PAYLOAD_LEN			300
#define RX_BUF_MAX_CNT              1000        /* Maximum receive Byte length      */
#define GSM_RX_WAITTIME             10          /* Waitime for Uart Payload receiving   */
#define MQTT_PUBLISH_DELAY          5000


/* Typedef -----------------------------------------------------------*/
/*
 * Enum for Bool handle
 */
typedef enum
{
    False = 0,
    True = !False

}Bool_E;

/*
 * Struct can handle USART receive Bytes
 * @brief
 */
typedef struct{
    uint8_t IGONdf[10];
    uint8_t IGOFFdf[10];
    uint8_t LOWBATCUT[10];
    uint8_t IMSPEED[10];
    uint8_t URL[25];
    uint8_t Key[15];
    uint8_t FWURL[30];
    uint8_t IMSI[16];
}SET_EVENT;
typedef struct{
       uint8_t Latitude[15];
       uint8_t Longitude[15];
       uint8_t hdop[10];
       uint8_t satellites[6];
       uint8_t Date[11];
       uint8_t Time[9];
       uint8_t speed[6];
       uint8_t Lac[10];
       uint8_t CID[11];
       uint8_t digitalInputStr[2];
       uint8_t speed_km[10];
       uint8_t IMEI[16];
       uint8_t IMSI[16];
       uint8_t MCC[4];
       uint8_t MNC[3];
       uint8_t cog[10];
       uint8_t etime[12];
       uint8_t pnStr[20];
       uint8_t str_km[8];
        uint8_t odometer[8];
        uint8_t odometer1[8];
        uint8_t odometer2[8];

}stream_iot;

typedef struct
{
    volatile uint8_t    rxBuf[RX_BUF_SIZE];
    volatile uint8_t    rxByte;
    volatile uint8_t    Cmd;
    volatile uint16_t   rxCnt;
    volatile uint16_t   timeCnt;
    volatile uint8_t    rxDelay;
    volatile Bool_E     rxFlag;
    volatile Bool_E     sendEnd;
    volatile Bool_E     rxEnd;

}Gsm_Handle_S;
//typedef struct{
  //  uint8_t Lac[10];
    //uint8_t CID[11];
    //uint8_t speed_km[10];
    //uint8_t IMSI[16];
    //uint8_t MCC[4];
    //uint8_t MNC[3];
//}fdata;
typedef struct
{
    uint8_t Serial_Number;

    Bool_E relay;
    Bool_E Buzzer;

    Bool_E DigitalInput1;
    Bool_E DigitalInput2;
    Bool_E DigitalInput3;
    Bool_E DigitalInput4;
    Bool_E DigitalOutput1;
    Bool_E DigitalOutput2;
    Bool_E DigitalOutput3;
    Bool_E DigitalOutput4;

} GPS_HandleType_S;
/*
 * @brief Enum can handle GSM States
 */

typedef enum
{
    GSM_STATE_TEST = 0,
    GSM_STATE_RESET,
    GSM_STATE_INIT,
    GSM_STATE_NETWORKREG,
    GSM_STATE_MQTTSTART,
    GSM_STATE_MQTTPUB,
    GSM_STATE_MQTTSUB,
    GSM_STATE_MQTTDISCONNECT,
    GSM_STATE_MQTTIDLE,
    GSM_STATE_GETCLOCK,
    GSM_STATE_GPSENABLE,
    GSM_STATE_GPSGETENABLE,
    GSM_STATE_GPSNETENABLE,
    GSM_STATE_GPSGETDISABLE,

}GSM_Handle_E;

/**
  * @brief Status Enum definition
  */
typedef enum
{
    Cmd_Send,
    Cmd_Waiting

}Substatus_E;


/**
  * @brief Status structures definition
  */
typedef enum
{
    AT_Ok = 0,
    AT_Error,
    AT_Busy,
    AT_Timeout

}Status_E;

typedef enum{
    Default = 0,
    SET_IOT_Settings,//1
    Set_IOT_Server_Settings,//2
    Get_IOT_Settings,//3
    Get_IOT_Server_Settings,//4
    Immobilize_ON,//5
    Immobilize_OFF,//6
    FOTA,
    Ignition_ON,   //BUTTON_ON
    Ignition_OFF, //BUTTON_OFF
    Bootnotification
}Pub_Events_E;

void prepare_IOTsettings_frame(void);
void prepare_IOTServer_Settings_frame(void);
void prepare_ImmobilizeON_frame(void);
void prepare_ImmobilizeOFF_frame(void);
void prepare_defaultframe(void);
void prepare_Bootframe(void);
void prepare_IgnitionON_frame(void);
void prepare_IgnitionOFF_frame(void);
void firmware_success(void);
void firmware_failure(void);


/* Variables ---------------------------------------------------------*/
extern GSM_Handle_E gsmState;
extern Gsm_Handle_S gsmS;
extern GPS_HandleType_S gpsS;
extern volatile Bool_E Debug_SendEnd;
extern volatile int32_t Accelerometer[3];
extern volatile int32_t Gyroscope[3];
extern uint8_t Eventstate;
extern uint8_t IMEI_no[20] ;
/* Function prototypes -----------------------------------------------*/
void debugPrintf(uint8_t *buf, uint16_t len);
void UartPrintf(uint8_t *buf, uint16_t len);
void Gsm_timer1MSCallback(void);
void Gsm_PollingProcess(void);
void Gsm_rxCallback(uint8_t rxByte);
extern void Delay_MilliSec(uint16_t Cnt);

#ifdef __cplusplus
}
#endif

#endif /* INC_OCPP_H_ */
