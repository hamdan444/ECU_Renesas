/*
 * atCmd.c
 *
 *  Created on: Dec 09, 2021
 *      Author: Yoganathan V
 */

/* Includes ------------------------------------------------------------------*/
#include "atCmd.h"
#include "gsmCmd.h"
#include <stdlib.h>
#include <stdbool.h>
#include <stdio.h>
#include <math.h>
#include "string.h"
#include <time.h>
#define EARTH_RADIUS_KM 6371.0
#define PI 3.14159265358979323846
#define  KNOTS_TO_km  1.852
bool Server_flag=false;
//#include "r_rtc.h"
/* Typedef -------------------------------------------------------------------*/
Gsm_Handle_S gsmS =
{ 0 };
GPS_HandleType_S gpsS =
{ 0 };
GSM_Handle_E gsmState = GSM_STATE_RESET;
stream_iot IOT={ 0 };
SET_EVENT EN={ 0 };
bool upgradeStatus;
time_t convertToEpoch(char *date, char *time);
double convertToDecimalDegrees(double dm);
double degToRad(double degrees);
double convertToDecimalDegrees(double dm);
double haversine(double lat1, double lon1, double lat2, double lon2);
void Odometer_value(void);
/* Define -------------------------------------------------------------------*/
static void fill_Integer(uint32_t data);
/* Macro --------------------------------------------------------------------*/

/* Variables ----------------------------------------------------------------*/
static volatile uint8_t mqttPayload[MQTT_BUF_SIZE] =
{ 0 };
static volatile uint32_t MQTT_PubDelay = 0;
volatile Bool_E Debug_SendEnd = False;
Bool_E imeiStart;
volatile uint8_t *ptr = NULL;
//void convert_cclk_to_epoch(const char* date, const char* time);
//void initRTC(void);
volatile uint8_t *sp;
uint64_t epoch=0;

double sp_km=0.0,speed_knots=0.0;
uint8_t IMEI_no[20] = "863906060002361";
char digitalInputStr[2] = {0};
uint8_t Eventstate =  0;
bool BootSend = true;
bool IS_Indication = false;
bool Previous_IS = False;
bool Current_IS;
Bool_E islive;

double prev_lat = 0.0, prev_lon = 0.0;
    double total_distance_km = 0.0,total=0.0,t=0.0;
bool IS_event_send = false;
volatile uint8_t real_speed[10]={0};
double dLat,dLon;
//uint8_t *pt = buffer;
static uint64_t pn=0;
char gsmFormattedDateTime[30] ;
//struct tm set_vale;

//time_t epochTime;
//time_t epochTime = 17202529906;
char bu[30];
//time_t epochTimeBuffer;
uint8_t igondfValue;
uint8_t igooffdfValue;
static void Gsm_SendCmd(uint8_t *buf, uint16_t len)
{


    debugPrintf(buf,len);

    gsmS.sendEnd = False;

    R_SCI_UART_Write (&g_uart2_ctrl, buf, len);

     while (!gsmS.sendEnd) ;


}
time_t convertToEpoch(char *date, char *time) {
    struct tm t = {0};

    t.tm_year = atoi(&date[0]) + 100;
    t.tm_mon = atoi(&date[3]) - 1;
    t.tm_mday = atoi(&date[6]);
    t.tm_hour = atoi(&time[0]);
    t.tm_min = atoi(&time[3]);
    t.tm_sec = atoi(&time[6]);
   // t.tm_isdst = -1;

    time_t epochTime = mktime(&t);

    return epochTime;
}
double degToRad(double degrees) {
    return degrees * (PI / 180);
}
double haversine(double lat1, double lon1, double lat2, double lon2) {

    dLat = degToRad(lat2 - lat1);
     dLon = degToRad(lon2 - lon1);
    lat1 = degToRad(lat1);
    lat2 = degToRad(lat2);

    double a = sin(dLat / 2) * sin(dLat / 2) +
               cos(lat1) * cos(lat2) * sin(dLon / 2) * sin(dLon / 2);

    double c = 2 * atan2(sqrt(a), sqrt(1 - a));

    return EARTH_RADIUS_KM * c;
}
// Function to convert from degrees and minutes (DM) to decimal degrees (DD)
 double convertToDecimalDegrees(double dm) {
    int degrees = (int)(dm / 100);
    double minutes = dm - (degrees * 100);
    return degrees + (minutes / 60.0);
}
void Odometer_value(void) {

}


double equirectangular_approx(double lat1, double lon1, double lat2, double lon2) {
    double dLat = degToRad(lat2 - lat1);
    double dLon = degToRad(lon2 - lon1);

    double lat_mid = degToRad((lat1 + lat2) / 2);  // Midpoint latitude

    double x = dLon * cos(lat_mid);  // Adjust the difference in longitude
    double y = dLat;

    // Distance calculation using Pythagoras' theorem
    return EARTH_RADIUS_KM * sqrt(x * x + y * y);
}
void Odometer_Test(void) {
    if (prev_lat != 0.0 && prev_lon != 0.0) {
        double cur_lat = atof((char*) IOT.Latitude);  // Ensure valid data in IOT.Latitude
        double cur_lon = atof((char*) IOT.Longitude); // Ensure valid data in IOT.Longitude

        double distance = equirectangular_approx(prev_lat, prev_lon, cur_lat, cur_lon);
        t += distance;  // Update total distance
    }

    // Update previous coordinates
    prev_lat = atof((char*) IOT.Latitude);
    prev_lon = atof((char*) IOT.Longitude);
}
static void fill_Integer(uint32_t data)
{
    uint8_t len = 0, tempBuf[15] =
    { 0 };
    while (data)
    {
        tempBuf[len++] = (uint8_t ) (data % 10) + 0x30;
        data /= 10;
    }
    while (len--)
    {
        *ptr++ = tempBuf[len];
    }
}

static void fill_String(const uint8_t *src)
{
    while (*src)
    {
        *ptr++ = *src++;
    }
}

void UartPrintf(uint8_t *buf, uint16_t len)
{
    (void) buf;
    (void) len;
    //Debug_SendEnd = False;
//    R_SCI_UART_Write(&g_uart1_ctrl, buf, len);
    // while(!Debug_SendEnd);

}


/*
 static void serial_num(void)
 {
 unsigned char
 }*/

/**
 * @brief Gsm Polling process will handle all the recieved and send
 to through GSM. This function should call in loop
 * @param  none
 * @retval none
 */
//static void Gsm_PrepareMQTTtxpayload(void)
//{
//    int32_t data = 0;
//    ptr = &mqttPayload[0];
//
//    memset((char *)mqttPayload, 0, MQTT_BUF_SIZE);
//
//    fill_String((uint8_t *)"{\"Model\":\"");
//    fill_String((uint8_t *)&PubSerialNo[0]);
//
//    fill_String((uint8_t *)"\",\"LAT\":\"");
//    fill_String((uint8_t *)gpsS.Latitude);
//
//    fill_String((uint8_t *)"\",\"LON\":\"");
//    fill_String((uint8_t *)gpsS.Longitude);
//
//    fill_String((uint8_t *)"\",\"DATE\":\"");
//    fill_String((uint8_t *)gpsS.Date);
//
//    fill_String((uint8_t *)"\",\"TIME\":\"");
//    fill_String((uint8_t *)gpsS.Time);
//
//    fill_String((uint8_t *)"\",\"IAMPS\":\"");
//    fill_String((uint8_t *)IAmps);
//
//    fill_String((uint8_t *)"\",\"DOP\":\"");
//    *ptr++ = gpsS.DigitalOutput1 + 0x30;
//    *ptr++ = gpsS.DigitalOutput2 + 0x30;
//    *ptr++ = gpsS.DigitalOutput3 + 0x30;
//    *ptr++ = gpsS.DigitalOutput4 + 0x30;
//
//    fill_String((uint8_t *)"\",\"DIP\":\"");
//    *ptr++ = gpsS.DigitalInput1 + 0x30;
//    *ptr++ = gpsS.DigitalInput2 + 0x30;
//    *ptr++ = gpsS.DigitalInput3 + 0x30;
//    *ptr++ = gpsS.DigitalInput4 + 0x30;
//
//    fill_String((uint8_t *)"\",\"RLY\":\"");
//    *ptr++ = gpsS.relay + 0x30;
//
////    fill_String((uint8_t *)"\",\"BUZZER\":\"");
////    *ptr++ = gpsS.Buzzer + 0x30;
//
//    fill_String((uint8_t *)"\",\"PAKV\":\"");
//    fill_Integer((uint32_t)voltage);
//
//    fill_String((uint8_t *)"\",\"ACC\":\"");
//    if(Accelerometer[0] & (1 << 31)) {
//        data = Accelerometer[0] * (-1);
//        fill_String((uint8_t *)"N");
//    }else {
//        data = Accelerometer[0];
//        fill_String((uint8_t *)"P");
//    }
//    fill_Integer((uint32_t)data);
//
//    fill_String((uint8_t *)",");
//    if(Accelerometer[1] & (1 << 31)) {
//        data = Accelerometer[1] * (-1);
//        fill_String((uint8_t *)"N");
//    }else {
//        data = Accelerometer[1];
//        fill_String((uint8_t *)"P");
//    }
//    fill_Integer((uint32_t)data);
//
//    fill_String((uint8_t *)",");
//    if(Accelerometer[2] & (1 << 31)) {
//        data = Accelerometer[2] * (-1);
//        fill_String((uint8_t *)"N");
//    }else {
//        data = Accelerometer[2];
//        fill_String((uint8_t *)"P");
//    }
//    fill_Integer((uint32_t)data);
//
//    fill_String((uint8_t *)"\",\"GYRO\":\"");
//    if(Gyroscope[0] & (1 << 31)) {
//        data = Gyroscope[0] * (-1);
//        fill_String((uint8_t *)"N");
//    }else {
//        data = Gyroscope[0];
//        fill_String((uint8_t *)"P");
//    }
//    fill_Integer((uint32_t)data);
//
//    fill_String((uint8_t *)",");
//    if(Gyroscope[1] & (1 << 31)) {
//        data = Gyroscope[1] * (-1);
//        fill_String((uint8_t *)"N");
//    }else {
//        data = Gyroscope[1];
//        fill_String((uint8_t *)"P");
//    }
//    fill_Integer((uint32_t)data);
//
//    fill_String((uint8_t *)",");
//    if(Gyroscope[2] & (1 << 31)) {
//        data = Gyroscope[2] * (-1);
//        fill_String((uint8_t *)"N");
//    }else {
//        data = Gyroscope[2];
//        fill_String((uint8_t *)"P");
//    }
//    fill_Integer((uint32_t)data);
//
//    fill_String((uint8_t *)"\"}");
// }


static void Gsm_PrepareMQTTtxpayload(void)
{
//    int32_t data = 0;
    if(BootSend)
    {
        Eventstate =Bootnotification;
    }
    switch(Eventstate)
        {
            case SET_IOT_Settings:

                prepare_IOTsettings_frame();
                IS_event_send = true;
                break;
            case Set_IOT_Server_Settings:

                prepare_IOTServer_Settings_frame();
                IS_event_send = true;
                break;
            case Get_IOT_Settings:

                prepare_IOTsettings_frame();
                IS_event_send = true;
                break;
            case Get_IOT_Server_Settings:

                prepare_IOTServer_Settings_frame();
                IS_event_send = true;
                break;
            case Immobilize_ON:
                prepare_ImmobilizeON_frame();
                IS_event_send = true;
                break;
            case Immobilize_OFF:
                prepare_ImmobilizeOFF_frame();
                IS_event_send = true;
                break;
            case FOTA:
                 firmware_failure();
                   IS_event_send = true;
                              break;

            case Ignition_ON:
                prepare_IgnitionON_frame();
                IS_event_send = true;
                  break;
            case Ignition_OFF:
                prepare_IgnitionOFF_frame();
                IS_event_send = true;
                 break;

            case Bootnotification:
                prepare_Bootframe();
                break;
            default:
                prepare_defaultframe();
                break;


        }
}
void prepare_IOTsettings_frame(void)
{
        ptr = &mqttPayload[0];
        //strcpy(EN.IMSI,IOT.IMSI);
        memset ((char*) mqttPayload, 0, MQTT_BUF_SIZE);

        fill_String ((uint8_t*) "{\"IMEI\":\"");
        fill_String ((uint8_t*) IOT.IMEI);
        fill_String ((uint8_t*) "\",");

        fill_String ((uint8_t*) "\"V\":");
        fill_String ((uint8_t*) "\"Entoo\",");

        fill_String ((uint8_t*) "\"FV\":");
        fill_String ((uint8_t*) "\"1.2.0\",");

        fill_String ((uint8_t*) "\"EID\":");
        fill_String ((uint8_t*) "\"7\",");

        fill_String ((uint8_t*) "\"IGONDF\":");
        fill_String ((uint8_t*) EN.IGONdf);
        fill_String ((uint8_t*) "\",");
        fill_String ((uint8_t*) "\"IGOFFDF\":");
        fill_String ((uint8_t*) EN.IGOFFdf);
       // fill_String ((uint8_t*) "\"30\",");
        fill_String ((uint8_t*) "\",");
        fill_String ((uint8_t*) "\"LOWBATCUTOFF\":");
        fill_String ((uint8_t*) EN.LOWBATCUT);
        fill_String ((uint8_t*) "\",");
        fill_String ((uint8_t*) "\"IMSPEED\":");
        fill_String ((uint8_t*) EN.IMSPEED);
        fill_String ((uint8_t*) "\",");
        fill_String ((uint8_t*) "\"IMSI\":");
        fill_String ((uint8_t*) IOT.IMSI);
        fill_String ((uint8_t*) "}");

}

void prepare_IOTServer_Settings_frame(void)
{

    ptr = &mqttPayload[0];

    memset ((char*) mqttPayload, 0, MQTT_BUF_SIZE);

    fill_String ((uint8_t*) "{\"IMEI\":\"");
    fill_String ((uint8_t*) IOT.IMEI);
    fill_String ((uint8_t*) "\",");

    fill_String ((uint8_t*) "\"V\":");
    fill_String ((uint8_t*) "\"Entoo\",");

    fill_String ((uint8_t*) "\"FV\":");
    fill_String ((uint8_t*) "\"1.2.0\",");

    fill_String ((uint8_t*) "\"EID\":");
    fill_String ((uint8_t*) "\"8\",");

    fill_String ((uint8_t*) "\"IMSI\":");
    fill_String ((uint8_t*) IOT.IMSI);
    fill_String ((uint8_t*) "\",");


    fill_String ((uint8_t*) "\"URL\":");
    fill_String ((uint8_t*) EN.URL);
    fill_String ((uint8_t*) "\",");
    fill_String ((uint8_t*) "\"Key\":");
    fill_String ((uint8_t*) EN.Key);
    fill_String ((uint8_t*) "\",");
    fill_String ((uint8_t*) "}");

}
void prepare_ImmobilizeON_frame(void)

{

    ptr = &mqttPayload[0];

    memset ((char*) mqttPayload, 0, MQTT_BUF_SIZE);

    fill_String ((uint8_t*) "{\"IMEI\":\"");
    fill_String ((uint8_t*) IOT.IMEI);
    fill_String ((uint8_t*) "\",");

    fill_String ((uint8_t*) "\"V\":");
    fill_String ((uint8_t*) "\"Entoo\",");

    fill_String ((uint8_t*) "\"FV\":");
    fill_String ((uint8_t*) "\"1.2.0\",");

    fill_String ((uint8_t*) "\"EID\":");
    fill_String ((uint8_t*) "\"3\",");

    fill_String ((uint8_t*) "\"PS\":");
    if(islive){

        fill_String ((uint8_t*) "\"1\",");
    }else {

        fill_String ((uint8_t*) "\"0\",");
    }

    fill_String ((uint8_t*) "\"T\":");
    fill_String ((uint8_t*) IOT.etime);
       fill_String ((uint8_t*) "\",");


    fill_String ((uint8_t*) "\"LAT\":\"");
    fill_String ((uint8_t*) IOT.Latitude);
    fill_String ((uint8_t*) "\",");

    fill_String ((uint8_t*) "\"LON\":\"");
    fill_String ((uint8_t*) IOT.Longitude);
    fill_String ((uint8_t*) "\",");

    fill_String ((uint8_t*) "\"S\":");
    fill_String ((uint8_t*) IOT.speed);

    fill_String ((uint8_t*) "\"COG\":");
    fill_String ((uint8_t*) IOT.cog);
    fill_String ((uint8_t*) "\",");

    fill_String ((uint8_t*) "\"LAC\":");
    fill_String ((uint8_t*) IOT.Lac);
    fill_String ((uint8_t*) "\",");

    fill_String ((uint8_t*) "\"CID\":");
    fill_String ((uint8_t*) IOT.CID);
    fill_String ((uint8_t*) "\",");

    fill_String ((uint8_t*) "\"NOS\":");
    fill_String ((uint8_t*) IOT.CID);
     fill_String ((uint8_t*) "\",");
    fill_String ((uint8_t*) "\"19\",");

    fill_String ((uint8_t*) "\"HDOP\":");
    fill_String ((uint8_t*) IOT.hdop);
    fill_String ((uint8_t*) "\",");


    fill_String ((uint8_t*) "\"OD\":");
    fill_String ((uint8_t*) IOT.odometer);
    fill_String ((uint8_t*) "\",");

    fill_String ((uint8_t*) "\"MC\":");
    fill_String ((uint8_t*) IOT.MCC);
     fill_String ((uint8_t*) "\",");


    fill_String ((uint8_t*) "\"MN\":");
    fill_String ((uint8_t*) IOT.MNC);
     fill_String ((uint8_t*) "\",");


    fill_String ((uint8_t*) "\"MSV\":");
    fill_String ((uint8_t*) "\"053.3\",");

    fill_String ((uint8_t*) "\"SS\":");
    fill_String ((uint8_t*) IOT.satellites);
     fill_String ((uint8_t*) "\",");



    if (gpsS.DigitalInput4 == 0) {
        strcpy(IOT.digitalInputStr, "0");
    } else if (gpsS.DigitalInput4 == 1) {
        strcpy(IOT.digitalInputStr, "1");
    }

    fill_String ((uint8_t*) "\"IS\":\"");
    fill_String ((uint8_t*) &IOT.digitalInputStr);
    fill_String ((uint8_t*) "\",");
//    fill_String ((uint8_t*) "\"digitalInputStr\",");

    fill_String ((uint8_t*) "\"POS\":");
    fill_String ((uint8_t*) "\"1\",");

    fill_String ((uint8_t*) "\"IM\":");
    fill_String ((uint8_t*) "\"0\",");

    fill_String ((uint8_t*) "\"IMSI\":");
    fill_String ((uint8_t*) IOT.IMSI);
    fill_String ((uint8_t*) "\",");
   // fill_String ((uint8_t*) "\"3134600000000001\",");

    fill_String ((uint8_t*) "\"IV\":");
    fill_String ((uint8_t*) "\"5\"}");

}
void prepare_ImmobilizeOFF_frame(void)
{
    ptr = &mqttPayload[0];

    memset ((char*) mqttPayload, 0, MQTT_BUF_SIZE);

    fill_String ((uint8_t*) "{\"IMEI\":\"");
    fill_String ((uint8_t*) IOT.IMEI);
    fill_String ((uint8_t*) "\",");

    fill_String ((uint8_t*) "\"V\":");
    fill_String ((uint8_t*) "\"Entoo\",");

    fill_String ((uint8_t*) "\"FV\":");
    fill_String ((uint8_t*) "\"1.2.0\",");

    fill_String ((uint8_t*) "\"EID\":");
    fill_String ((uint8_t*) "\"4\",");

    fill_String ((uint8_t*) "\"PS\":");
    if(islive){

        fill_String ((uint8_t*) "\"1\",");
    }else {

        fill_String ((uint8_t*) "\"0\",");
    }

    fill_String ((uint8_t*) "\"T\":");
    fill_String ((uint8_t*) IOT.etime);
    fill_String ((uint8_t*) "\",");

    fill_String ((uint8_t*) "\"LAT\":\"");
    fill_String ((uint8_t*) IOT.Latitude);
    fill_String ((uint8_t*) "\",");

    fill_String ((uint8_t*) "\"LON\":\"");
    fill_String ((uint8_t*) IOT.Longitude);
    fill_String ((uint8_t*) "\",");

       fill_String ((uint8_t*) "\"S\":");
       fill_String ((uint8_t*) IOT.speed);

       fill_String ((uint8_t*) "\"COG\":");
       fill_String ((uint8_t*) IOT.cog);
       fill_String ((uint8_t*) "\",");

       fill_String ((uint8_t*) "\"LAC\":");
       fill_String ((uint8_t*) IOT.Lac);
       fill_String ((uint8_t*) "\",");

       fill_String ((uint8_t*) "\"CID\":");
       fill_String ((uint8_t*) IOT.CID);
       fill_String ((uint8_t*) "\",");

       fill_String ((uint8_t*) "\"NOS\":");
       fill_String ((uint8_t*) IOT.satellites);
        fill_String ((uint8_t*) "\",");
       fill_String ((uint8_t*) "\"19\",");

       fill_String ((uint8_t*) "\"HDOP\":");
       fill_String ((uint8_t*) IOT.hdop);
        fill_String ((uint8_t*) "\",");


       fill_String ((uint8_t*) "\"OD\":");
       fill_String ((uint8_t*) IOT.odometer);
       fill_String ((uint8_t*) "\",");
       fill_String ((uint8_t*) "\"MC\":");
       fill_String ((uint8_t*) IOT.MCC);
        fill_String ((uint8_t*) "\",");


       fill_String ((uint8_t*) "\"MN\":");
       fill_String ((uint8_t*) IOT.MNC);
        fill_String ((uint8_t*) "\",");


       fill_String ((uint8_t*) "\"MSV\":");
       fill_String ((uint8_t*) "\"053.3\",");

       fill_String ((uint8_t*) "\"SS\":");
       fill_String ((uint8_t*) IOT.satellites);
        fill_String ((uint8_t*) "\",");


    if (gpsS.DigitalInput4 == 0) {
        strcpy(digitalInputStr, "0");
    } else if (gpsS.DigitalInput4 == 1) {
        strcpy(digitalInputStr, "1");
    }

    fill_String ((uint8_t*) "\"IS\":\"");
    fill_String ((uint8_t*) &digitalInputStr);
    fill_String ((uint8_t*) "\",");


    fill_String ((uint8_t*) "\"POS\":");
    fill_String ((uint8_t*) "\"1\",");

    fill_String ((uint8_t*) "\"IM\":");
    fill_String ((uint8_t*) "\"0\",");

    fill_String ((uint8_t*) "\"IMSI\":");
    fill_String ((uint8_t*) IOT.IMSI);
    fill_String ((uint8_t*) "\",");
   // fill_String ((uint8_t*) "\"3134600000000001\",");

    fill_String ((uint8_t*) "\"IV\":");
    fill_String ((uint8_t*) "\"5\"}");



}
void prepare_IgnitionON_frame(void){
    ptr = &mqttPayload[0];

    memset ((char*) mqttPayload, 0, MQTT_BUF_SIZE);

    fill_String ((uint8_t*) "{\"IMEI\":\"");
    fill_String ((uint8_t*) IOT.IMEI);
    fill_String ((uint8_t*) "\",");

    fill_String ((uint8_t*) "\"V\":");
    fill_String ((uint8_t*) "\"Entoo\",");

    fill_String ((uint8_t*) "\"FV\":");
    fill_String ((uint8_t*) "\"1.2.0\",");

    fill_String ((uint8_t*) "\"EID\":");
    fill_String ((uint8_t*) "\"1\",");

    fill_String ((uint8_t*) "\"PS\":");
    if(islive){

        fill_String ((uint8_t*) "\"1\",");
    }else {

        fill_String ((uint8_t*) "\"0\",");
    }

    fill_String ((uint8_t*) "\"T\":");
    fill_String ((uint8_t*) IOT.etime);

    fill_String ((uint8_t*) "\"LAT\":\"");
    fill_String ((uint8_t*) IOT.Latitude);
    fill_String ((uint8_t*) "\",");

    fill_String ((uint8_t*) "\"LON\":\"");
    fill_String ((uint8_t*) IOT.Longitude);
    fill_String ((uint8_t*) "\",");

       fill_String ((uint8_t*) "\"S\":");
       fill_String ((uint8_t*) IOT.speed);

       fill_String ((uint8_t*) "\"COG\":");
       fill_String ((uint8_t*) IOT.cog);
       fill_String ((uint8_t*) "\",");

       fill_String ((uint8_t*) "\"LAC\":");
       fill_String ((uint8_t*) IOT.Lac);
       fill_String ((uint8_t*) "\",");

       fill_String ((uint8_t*) "\"CID\":");
       fill_String ((uint8_t*) IOT.CID);
       fill_String ((uint8_t*) "\",");

       fill_String ((uint8_t*) "\"NOS\":");
       fill_String ((uint8_t*) IOT.satellites);
        fill_String ((uint8_t*) "\",");
       fill_String ((uint8_t*) "\"19\",");

       fill_String ((uint8_t*) "\"HDOP\":");
       fill_String ((uint8_t*) IOT.hdop);
        fill_String ((uint8_t*) "\",");


       fill_String ((uint8_t*) "\"OD\":");
       fill_String ((uint8_t*) IOT.odometer);
       fill_String ((uint8_t*) "\",");
       fill_String ((uint8_t*) "\"MC\":");
       fill_String ((uint8_t*) IOT.MCC);
        fill_String ((uint8_t*) "\",");


       fill_String ((uint8_t*) "\"MN\":");
       fill_String ((uint8_t*) IOT.MNC);
        fill_String ((uint8_t*) "\",");


       fill_String ((uint8_t*) "\"MSV\":");
       fill_String ((uint8_t*) "\"053.3\",");

       fill_String ((uint8_t*) "\"SS\":");
       fill_String ((uint8_t*) IOT.satellites);
        fill_String ((uint8_t*) "\",");


    if (gpsS.DigitalInput4 == 0) {
        strcpy(digitalInputStr, "0");
    } else if (gpsS.DigitalInput4 == 1) {
        strcpy(digitalInputStr, "1");
    }

    fill_String ((uint8_t*) "\"IS\":\"");
    fill_String ((uint8_t*) &digitalInputStr);
    fill_String ((uint8_t*) "\",");

    fill_String ((uint8_t*) "\"POS\":");
    fill_String ((uint8_t*) "\"1\",");

    fill_String ((uint8_t*) "\"IM\":");
    fill_String ((uint8_t*) "\"0\",");

    fill_String ((uint8_t*) "\"IMSI\":");
    fill_String ((uint8_t*) IOT.IMSI);
    fill_String ((uint8_t*) "\",");
    fill_String ((uint8_t*) "\"IV\":");
    fill_String ((uint8_t*) "\"5\"}");
}
void prepare_IgnitionOFF_frame(void){
    ptr = &mqttPayload[0];

    memset ((char*) mqttPayload, 0, MQTT_BUF_SIZE);

    fill_String ((uint8_t*) "{\"IMEI\":\"");
        fill_String ((uint8_t*) IOT.IMEI);
        fill_String ((uint8_t*) "\",");
        fill_String ((uint8_t*) "\"V\":");
        fill_String ((uint8_t*) "\"Entoo\",");

        fill_String ((uint8_t*) "\"FV\":");
        fill_String ((uint8_t*) "\"1.2.0\",");

        fill_String ((uint8_t*) "\"EID\":");
        fill_String ((uint8_t*) "\"2\",");

        fill_String ((uint8_t*) "\"PS\":");
        if(islive){

            fill_String ((uint8_t*) "\"1\",");
        }else {

            fill_String ((uint8_t*) "\"0\",");
        }

        fill_String ((uint8_t*) "\"T\":");
        fill_String ((uint8_t*) IOT.etime);

        fill_String ((uint8_t*) "\"LAT\":\"");
        fill_String ((uint8_t*) IOT.Latitude);
        fill_String ((uint8_t*) "\",");

        fill_String ((uint8_t*) "\"LON\":\"");
        fill_String ((uint8_t*) IOT.Longitude);
        fill_String ((uint8_t*) "\",");

           fill_String ((uint8_t*) "\"S\":");
           fill_String ((uint8_t*) IOT.speed);

           fill_String ((uint8_t*) "\"COG\":");
           fill_String ((uint8_t*) IOT.cog);
           fill_String ((uint8_t*) "\",");

           fill_String ((uint8_t*) "\"LAC\":");
           fill_String ((uint8_t*) IOT.Lac);
           fill_String ((uint8_t*) "\",");

           fill_String ((uint8_t*) "\"CID\":");
           fill_String ((uint8_t*) IOT.CID);
           fill_String ((uint8_t*) "\",");

           fill_String ((uint8_t*) "\"NOS\":");
           fill_String ((uint8_t*) IOT.satellites);
            fill_String ((uint8_t*) "\",");
           fill_String ((uint8_t*) "\"19\",");

           fill_String ((uint8_t*) "\"HDOP\":");
           fill_String ((uint8_t*) IOT.hdop);
            fill_String ((uint8_t*) "\",");


           fill_String ((uint8_t*) "\"OD\":");
           fill_String ((uint8_t*) IOT.odometer);
           fill_String ((uint8_t*) "\",");
           fill_String ((uint8_t*) "\"MC\":");
           fill_String ((uint8_t*) IOT.MCC);
            fill_String ((uint8_t*) "\",");


           fill_String ((uint8_t*) "\"MN\":");
           fill_String ((uint8_t*) IOT.MNC);
            fill_String ((uint8_t*) "\",");


           fill_String ((uint8_t*) "\"MSV\":");
           fill_String ((uint8_t*) "\"053.3\",");

           fill_String ((uint8_t*) "\"SS\":");
           fill_String ((uint8_t*) IOT.satellites);
            fill_String ((uint8_t*) "\",");


        if (gpsS.DigitalInput4 == 0) {
            strcpy(digitalInputStr, "0");
        } else if (gpsS.DigitalInput4 == 1) {
            strcpy(digitalInputStr, "1");
        }

        fill_String ((uint8_t*) "\"IS\":\"");
        fill_String ((uint8_t*) &digitalInputStr);
        fill_String ((uint8_t*) "\",");


        fill_String ((uint8_t*) "\"POS\":");
        fill_String ((uint8_t*) "\"1\",");

        fill_String ((uint8_t*) "\"IM\":");
        fill_String ((uint8_t*) "\"0\",");

        fill_String ((uint8_t*) "\"IMSI\":");
        fill_String ((uint8_t*) IOT.IMSI);
        fill_String ((uint8_t*) "\",");

        fill_String ((uint8_t*) "\"IV\":");
        fill_String ((uint8_t*) "\"5\"}");
}
void  firmware_success(void){
    ptr = &mqttPayload[0];

       memset ((char*) mqttPayload, 0, MQTT_BUF_SIZE);

       fill_String ((uint8_t*) "{\"IMEI\":\"");
       fill_String ((uint8_t*) IOT.IMEI);
       fill_String ((uint8_t*) "\",");

       fill_String ((uint8_t*) "\"V\":");
       fill_String ((uint8_t*) "\"Entoo\",");

       fill_String ((uint8_t*) "\"FV\":");
       fill_String ((uint8_t*) "\"1.2.0\",");

       fill_String ((uint8_t*) "\"EID\":");
       fill_String ((uint8_t*) "\"9\",");
       fill_String ((uint8_t*) "\"IMSI\":");
       fill_String ((uint8_t*) IOT.IMSI);
       fill_String ((uint8_t*) "\",");

       fill_String ((uint8_t*) EN.FWURL);
       fill_String ((uint8_t*) "\",");
       fill_String ((uint8_t*) "\"Remarks\":");
       fill_String ((uint8_t*) "\"Successfull\"}");

}
void  firmware_failure(void){

    ptr = &mqttPayload[0];

       memset ((char*) mqttPayload, 0, MQTT_BUF_SIZE);

       fill_String ((uint8_t*) "{\"IMEI\":\"");
       fill_String ((uint8_t*) IOT.IMEI);
       fill_String ((uint8_t*) "\",");

       fill_String ((uint8_t*) "\"V\":");
       fill_String ((uint8_t*) "\"Entoo\",");

       fill_String ((uint8_t*) "\"FV\":");
       fill_String ((uint8_t*) "\"1.2.0\",");

       fill_String ((uint8_t*) "\"EID\":");
       fill_String ((uint8_t*) "\"10\",");
       fill_String ((uint8_t*) "\"IMSI\":");

       fill_String ((uint8_t*) "\"FWURL\":");
       fill_String ((uint8_t*) EN.FWURL);
           fill_String ((uint8_t*) "\",");
       fill_String ((uint8_t*) IOT.IMSI);
       fill_String ((uint8_t*) "\",");

       fill_String ((uint8_t*) "\"Remarks\":");
       fill_String ((uint8_t*) "\"Downloaded, Failed to Install\"}");

}
void prepare_defaultframe(void)
{

    ptr = &mqttPayload[0];

    memset ((char*) mqttPayload, 0, MQTT_BUF_SIZE);
  //  pt = buffer;

    fill_String ((uint8_t*) "{\"IMEI\":\"");
    fill_String ((uint8_t*) IOT.IMEI);
    fill_String ((uint8_t*) "\",");
    fill_String ((uint8_t*) "\"V\":");
    fill_String ((uint8_t*) "\"Entoo\",");
    fill_String ((uint8_t*) "\"FV\":");
    fill_String ((uint8_t*) "\"1.2.0\",");
    fill_String ((uint8_t*) "\"OD TEST1\":");
    Odometer_value();
    sprintf(IOT.odometer1, "%.2f", total);
    fill_String ((uint8_t*) IOT.odometer1);
    fill_String ((uint8_t*) "\"PS\":");
    if(islive){

        fill_String ((uint8_t*) "\"1\",");
    }else {

        fill_String ((uint8_t*) "\"0\",");
    }


    fill_String ((uint8_t*) "\"T\":");


   fill_String ((uint8_t*) IOT.etime);
 //  fill_String ((uint8_t*) IOT.Time);
    fill_String ((uint8_t*) "\",");
    fill_String ((uint8_t*) "\"LAT\":\"");
    fill_String ((uint8_t*) IOT.Latitude);
    fill_String ((uint8_t*) "\",");

    fill_String ((uint8_t*) "\"LON\":\"");
    fill_String ((uint8_t*) IOT.Longitude);
    fill_String ((uint8_t*) "\",");

    fill_String ((uint8_t*) "\"S\":");
   // sp=gpsS.speed;



    //sp_km=(float)(*sp)*1.852;
    //sprintf(.speed_km,"%.2f\n",sp_km);
    fill_String ((uint8_t*)IOT.speed);
    speed_knots = atof((char*) IOT.speed);
    sp_km = speed_knots * KNOTS_TO_km;
    fill_String ((uint8_t*) "\"S_km\":");
    sprintf(IOT.str_km, "%.2f", sp_km);
    fill_String ((uint8_t*) IOT.str_km);
    fill_String ((uint8_t*) "\",");
    //fill_String ((uint8_t*) "\"90\",");

    fill_String ((uint8_t*) "\"COG\":");
    fill_String ((uint8_t*) IOT.cog);
   // fill_String ((uint8_t*) "\"193.63\",");
    fill_String ((uint8_t*) "\",");
    fill_String ((uint8_t*) "\"LAC\":");
    fill_String ((uint8_t*) IOT.Lac);
    //fill_String ((uint8_t*) "\"61FC\",");
    fill_String ((uint8_t*) "\",");
    fill_String ((uint8_t*) "\"CID\":");
    fill_String ((uint8_t*) IOT.CID);
    fill_String ((uint8_t*) "\",");
   // fill_String ((uint8_t*) "\"38504\",");

    fill_String ((uint8_t*) "\"NOS\":");
    fill_String ((uint8_t*) IOT.satellites);
    fill_String ((uint8_t*) "\",");
    //0fill_String ((uint8_t*) "\"19\",");
   // char hdop_str[20];

       // Convert HDOP value to string
  //  snprintf(hdop_str, sizeof(hdop_str), "%.3f", hdop_value);
    fill_String ((uint8_t*) "\"HDOP\":");
    fill_String ((uint8_t*)IOT.hdop);
    fill_String ((uint8_t*) "\",");
    fill_String ((uint8_t*) "\"OD\":");
    sprintf(IOT.odometer, "%.2f", total_distance_km);
    fill_String ((uint8_t*) IOT.odometer);
    fill_String ((uint8_t*) "\",");
  //  fill_String ((uint8_t*) "\"000.0\",");

    fill_String ((uint8_t*) "\"MC\":");
    fill_String ((uint8_t*)  IOT.MCC);
    fill_String ((uint8_t*) "\",");
   // fill_String ((uint8_t*) "\"404\",");

    fill_String ((uint8_t*) "\"MN\":");
    fill_String ((uint8_t*)  IOT.MNC);
    fill_String ((uint8_t*) "\",");
   // fill_String ((uint8_t*) "\"x45\",");

    fill_String ((uint8_t*) "\"MSV\":");
    fill_String ((uint8_t*) "\"053.3\",");

    fill_String ((uint8_t*) "\"SS\":");
    fill_String ((uint8_t*) IOT.satellites);
    fill_String ((uint8_t*) "\",");


    if (gpsS.DigitalInput4 == 0) {
        strcpy(digitalInputStr, "0");
    } else if (gpsS.DigitalInput4 == 1) {
        strcpy(digitalInputStr, "1");
    }

    fill_String ((uint8_t*) "\"IS\":\"");
    fill_String ((uint8_t*) &digitalInputStr);
    fill_String ((uint8_t*) "\",");
//    fill_String ((uint8_t*) "\"digitalInputStr\",");

    fill_String ((uint8_t*) "\"POS\":");
    fill_String ((uint8_t*) "\"1\",");

    fill_String ((uint8_t*) "\"PN\":");
    pn++;

    sprintf(IOT.pnStr, "%lu", pn);
    fill_String((uint8_t*)IOT.pnStr);

    fill_String ((uint8_t*) "\",");

   // fill_String ((uint8_t*) "\"00000000000000000\",");

    fill_String ((uint8_t*) "\"IM\":");
    fill_String ((uint8_t*) "\"0\",");

    fill_String ((uint8_t*) "\"IMSI\":");
    fill_String ((uint8_t*) IOT.IMSI);
    fill_String ((uint8_t*) "\",");
    //fill_String ((uint8_t*) "\"3134600000000001\",");
    Odometer_Test();
       fill_String ((uint8_t*) "\"OD Test2\":");
       sprintf(IOT.odometer2, "%.2f", t);
      fill_String ((uint8_t*) IOT.odometer2);
      fill_String ((uint8_t*) "\",");
    fill_String ((uint8_t*) "\"IV\":");
    fill_String ((uint8_t*) "\"5\"}");

}

void prepare_Bootframe(void)
{
        ptr = &mqttPayload[0];

      memset ((char*) mqttPayload, 0, MQTT_BUF_SIZE);

      fill_String ((uint8_t*) "{\"IMEI\":\"");
      fill_String ((uint8_t*) IOT.IMEI);
      fill_String ((uint8_t*) "\",");

      fill_String ((uint8_t*) "\"EID\":");
      fill_String ((uint8_t*) "\"11\",");

      fill_String ((uint8_t*) "\"FV\":");
      fill_String ((uint8_t*) "\"1.3.0\",");

      fill_String ((uint8_t*) "\"IMSI\":");
      fill_String ((uint8_t*) IOT.IMSI);
      fill_String ((uint8_t*) "\",");

      fill_String ((uint8_t*) "\"V\":");
      fill_String ((uint8_t*) "\"Entoo\",");

      fill_String ((uint8_t*) "\"POS\":");
      fill_String ((uint8_t*) "\"1\",");

      fill_String ((uint8_t*) "\"T\":");
      fill_String ((uint8_t*) IOT.etime);
      fill_String ((uint8_t*) "\",");
      fill_String ((uint8_t*) "\",");
      if (gpsS.DigitalInput4 == 0) {
          strcpy(digitalInputStr, "0");
      } else if (gpsS.DigitalInput4 == 1) {
          strcpy(digitalInputStr, "1");
      }

      fill_String ((uint8_t*) "\"IS\":\"");
      fill_String ((uint8_t*) &digitalInputStr);
      fill_String ((uint8_t*) "\",");

      fill_String ((uint8_t*) "\"PS\":");
      if(islive){

             fill_String ((uint8_t*) "\"LIVE\"}");
         }else {

             fill_String ((uint8_t*) "\"HISTORY\"}");
         }
}

/**
 * @brief  Gsm_rxFrameHandle shall Handle the response
 * @param  none
 * @retval Status_E
 */
static Status_E Gsm_rxFrameHandle(void)
{

    Status_E status = AT_Busy;
    //

    if (gsmState <= GSM_STATE_NETWORKREG)
    {


        if (strstr ((char*) gsmS.rxBuf, "+CSQ: 99,99"))
        {
            status = AT_Busy;

        }
        else if (strstr ((char*) gsmS.rxBuf, "+CPIN:"))
        {
            if (strstr ((char*) gsmS.rxBuf, "READY"))
            {
                status = AT_Ok;
            }
            else if (strstr ((char*) gsmS.rxBuf, "SIM REMOVED"))
            {
                status = AT_Error;
            }

        }



        else if (strstr((char*) gsmS.rxBuf, "+CEREG"))
        {



                 int i = 0, n = 0;
                            Bool_E LACFlag = False;
                            Bool_E CIDFlag = False;

                           for (i = 0; i <= gsmS.rxCnt; i++)
                            {

                           if(LACFlag){

                                  IOT.Lac[n++] = gsmS.rxBuf[i];
                                   if( (gsmS.rxBuf[i + 1] == ',')){
                                       IOT.Lac[n] = '\0';
                                       LACFlag=False;
                                         CIDFlag=True;
                                  UartPrintf ((uint8_t*) IOT.Lac, 10);
                                  n = 0;
                                  i +=1;
                                  }
                         }
                           else if(CIDFlag) {
                                 IOT. CID[n++] = gsmS.rxBuf[i];
                                   if ((gsmS.rxBuf[i + 1] == ',')) {
                                       IOT.CID[n] = '\0';
                                  UartPrintf ((uint8_t*)IOT.CID , 10);
                                  break;
                                  }

                            }
                              else{
                                  if ((gsmS.rxBuf[i] == '+') && (gsmS.rxBuf[i + 6] == ':') && ((gsmS.rxBuf[i + 8] == '1'))){//||(gsmS.rxBuf[i + 8] == '11')
                                      status = AT_Ok;
                                             i += 9;
                                             LACFlag  = True;

                              }

                                  else{
                                      if(strstr((char*) gsmS.rxBuf, "+CEREG: 0,1")){
                                          status = AT_Ok;
                                      }
                                      else{
                                      status = AT_Busy;
                                      }
                                  }
            }
                            }
        }


        else if (strstr((char*) gsmS.rxBuf, "404")) {
            uint8_t i = 0, n = 0;
            Bool_E ImSIFlag = False;


            for (i = 0; i <= gsmS.rxCnt; i++) {
                if (ImSIFlag) {
                    IOT.IMSI[n++] = gsmS.rxBuf[i];  // Copy the digit
                    if (n == 15) {
                        IOT.IMSI[n] = '\0';
                        UartPrintf((uint8_t*) IOT.IMSI, 15);
                        break;
                    }
                } else {

                    if ((gsmS.rxBuf[i] == '4') && (gsmS.rxBuf[i + 3] == '4')) {
                        status = AT_Ok;
                        ImSIFlag = True;  // Begin capturing IMSI
                        IOT.MCC[0] = gsmS.rxBuf[i];
                        IOT. MCC[1] = gsmS.rxBuf[i + 1];
                        IOT. MCC[2] = gsmS.rxBuf[i + 2];
                        IOT. MCC[3] = '\0';
                        IOT.MNC[0] = gsmS.rxBuf[i + 3];
                        IOT.MNC[1] = gsmS.rxBuf[i + 4];
                        IOT.MNC[2] = '\0';
                        UartPrintf((uint8_t*) IOT.MCC, 3);
                        UartPrintf((uint8_t*) IOT.MNC, 2);
                        i -= 1;
                        n = 0;
                    }
                }
            }
        }
        else if (strstr((char*) gsmS.rxBuf, "IMEI:")){
                           uint8_t i = 0, n = 0;
                                      Bool_E IMEIFlag = False;
                                      for(i=0;i<=gsmS.rxCnt;i++){
                                          if(IMEIFlag){
                                          IOT.IMEI [n++] = gsmS.rxBuf[i];
                                              if(n==15){
                                                  IOT.IMSI[n] = '\0';
                                                  UartPrintf((uint8_t*) IOT.IMEI, 15);
                                                  break;
                                              }
                                          }
                                          else {

                                          if ((gsmS.rxBuf[i] == 'I') && (gsmS.rxBuf[i + 4] == ':')) {
                                                  status = AT_Ok;
                                              IMEIFlag = True;
                                              i +=4;
                                              n = 0;
                                      }
                                      }
                                      }
                                      }




     /*
      *
      *
                                  else  if (strstr((char*) gsmS.rxBuf, "OK")) {

                       uint8_t i = 0, n = 0;
                         imeiStart = False;

                       // Find the start of the IMEI number in the response
                       for (i = 0; i < gsmS.rxCnt; i++) {
                           if(imeiStart){
                           IOT.IMEI[n++] = gsmS.rxBuf[i];
                           if (n == 15) {
                               IOT.IMSI[n] = '\0';
                              UartPrintf((uint8_t*) IOT.IMSI, 15);
                                break;
                              }
                           }else{
                           if (gsmS.rxBuf[i] >= '"' && gsmS.rxBuf[i+1] <= '8') {
                               imeiStart = True;
                               status = AT_Ok;

                               i+=1;
                               n=0;

                           }


                   }
                           }
               }
        else if (strstr((char*) gsmS.rxBuf, "AT+CGSN")){
             if (strstr ((char*) gsmS.rxBuf, "OK")){
                 status = AT_Ok;
                 uint8_t i = 0, n = 0;
                 for(i=0;i<=gsmS.rxCnt;i++){
                     status = AT_Ok;
                     IOT.IMEI[n++]=gsmS.rxBuf[i];


            }
        }
        }

*/
        else if (strstr ((char*) gsmS.rxBuf, "ERROR"))
        {
            status = AT_Error;

        }
        else if (strstr ((char*) gsmS.rxBuf, "OK"))
        {
            status = AT_Ok;

        }
        else if (strstr ((char*) gsmS.rxBuf, "+CME ERROR"))
        {
            status = AT_Ok;
        }
        else
        {
            status = AT_Busy;
        }

    }
    else if (gsmState > GSM_STATE_NETWORKREG)
    {
        if (strstr ((char*) gsmS.rxBuf, ">"))
        {
            status = AT_Ok;

        }
        else if (strstr ((char*) gsmS.rxBuf, "+NETOPEN:"))
        {
            if (strstr ((char*) gsmS.rxBuf, "SUCC"))
            {
                status = AT_Ok;
            }
            else
            {
                status = AT_Busy;
            }

        }
        else if (strstr ((char*) gsmS.rxBuf, "+MIPSTART:"))
        {
            if (strstr ((char*) gsmS.rxBuf, "SUCC"))
            {
                status = AT_Ok;
            }
            else
            {
                status = AT_Busy;
            }

        }
        else if (strstr ((char*) gsmS.rxBuf, "+MCONNECT:"))
        {
            if (strstr ((char*) gsmS.rxBuf, "SUCC"))
            {
                status = AT_Ok;
            }
            else if(strstr ((char*) gsmS.rxBuf, "FAILURE"))
            {
                status = AT_Busy;
            }

        }
        else if (strstr ((char*) gsmS.rxBuf, "+MSUB:"))
        {
            if (strstr ((char*) gsmS.rxBuf, "OTA Topic"))
            {

                if((strstr ((char*) gsmS.rxBuf, "IMEI") || (strstr ((char*) gsmS.rxBuf, "AID" )|| (strstr ((char*) gsmS.rxBuf, "IGONDF") ||  (strstr ((char*) gsmS.rxBuf, "IGOFFDF") || (strstr ((char*) gsmS.rxBuf, "LOWBATCUTOFF") || (strstr ((char*) gsmS.rxBuf, "IMSPEED") ||(strstr ((char*) gsmS.rxBuf, "URL")||(strstr ((char*) gsmS.rxBuf, "KEY") ||(strstr ((char*) gsmS.rxBuf, "FWURL"))) ) )) ) ))))
                {
                    uint8_t i=0,n;
           //if(strstr ((char*) gsmS.rxBuf, "IGONDF") ||  (strstr ((char*) gsmS.rxBuf, "IGOFFDF") || (strstr ((char*) gsmS.rxBuf, "LOWBATCUTOFF") || (strstr ((char*) gsmS.rxBuf, "IMSPEED"))) )){
                    for( i = 0; i < gsmS.rxCnt; i++)
                    {
                        if(gsmS.rxBuf[i] == 'A' && gsmS.rxBuf[i+1] == 'I' && gsmS.rxBuf[i+2] == 'D'
                                                && gsmS.rxBuf[i+3] == '"' && gsmS.rxBuf[i+4] == ':')
                        {
                            Eventstate = gsmS.rxBuf[i+6] - '0';
                        }
                        else if(gsmS.rxBuf[i] == 'I' && gsmS.rxBuf[i+2] == 'O'  && gsmS.rxBuf[i+7] == ':'   ){// && gsmS.rxBuf[i+8] == '"'

                            uint8_t j = 8;
                                          while ( i + j < gsmS.rxCnt && gsmS.rxBuf[i + j] != ','  )//&& // Store until the next quote or end
                                          {

                                              EN.IGONdf[n++] = gsmS.rxBuf[i + j];
                                              j++;


                                          }

                                          n=0;
                        }
                        else if(gsmS.rxBuf[i] == 'I' && gsmS.rxBuf[i+2] == 'O'  && gsmS.rxBuf[i+8] == ':' ){//&& gsmS.rxBuf[i+9] == '"'

                                                    uint8_t j = 9;
                                                                  while ( i + j < gsmS.rxCnt && gsmS.rxBuf[i + j] != ','  )//&& // Store until the next quote or end
                                                                  {

                                                                      EN.IGOFFdf[n++] = gsmS.rxBuf[i + j];
                                                                      j++;


                                                                  }
                                                                  n=0;

                                                }
                        else if(gsmS.rxBuf[i] == 'L' && gsmS.rxBuf[i+9] == 'O'  && gsmS.rxBuf[i+13] == ':'   ){//gsmS.rxBuf[i+14] == '"'

                                                                      uint8_t j = 14;
                                                                                    while ( i + j < gsmS.rxCnt && gsmS.rxBuf[i + j] != ','  )//&& // Store until the next quote or end
                                                                                    {

                                                                                        EN.LOWBATCUT[n++] = gsmS.rxBuf[i + j];
                                                                                        j++;


                                                                                    }
                                                                                    n=0;

                                                                  }
                        else if(gsmS.rxBuf[i] == 'I' && gsmS.rxBuf[i+2] == 'S'  && gsmS.rxBuf[i+8] == ':'  ){//&&  gsmS.rxBuf[i+9] == '"'

                                                                        uint8_t j = 9;
                                                                                      while ( i + j < gsmS.rxCnt && gsmS.rxBuf[i + j] != ','  )//&& // Store until the next quote or end
                                                                                      {

                                                                                          EN.IMSPEED[n++] = gsmS.rxBuf[i + j];
                                                                                          j++;


                                                                                      }
                                                                                      n=0;


                                                                    }
                        else if(gsmS.rxBuf[i] == 'U' && gsmS.rxBuf[i+2] == 'L'  && gsmS.rxBuf[i+4] == ':'  ){//&&  gsmS.rxBuf[i+9] == '"'

                                                                                              uint8_t j = 5;
                                                                                                            while ( i + j < gsmS.rxCnt && gsmS.rxBuf[i + j] != ','  )//&& // Store until the next quote or end
                                                                                                            {

                                                                                                                EN.URL[n++] = gsmS.rxBuf[i + j];
                                                                                                                j++;


                                                                                                            }
                                                                                                            n=0;


                                                                                          }
                        else if(gsmS.rxBuf[i] == 'K' && gsmS.rxBuf[i+2] == 'Y'  && gsmS.rxBuf[i+4] == ':'  ){//&&  gsmS.rxBuf[i+9] == '"'

                                                                                              uint8_t j = 5;
                                                                                                            while ( i + j < gsmS.rxCnt && gsmS.rxBuf[i + j] != ','  )//&& // Store until the next quote or end
                                                                                                            {

                                                                                                                EN.Key[n++] = gsmS.rxBuf[i + j];
                                                                                                                j++;


                                                                                                            }
                                                                                                            n=0;


                                                                                          }
                        else if(gsmS.rxBuf[i] == 'K' && gsmS.rxBuf[i+2] == 'Y'  && gsmS.rxBuf[i+4] == ':'  ){//&&  gsmS.rxBuf[i+9] == '"'

                                                                                                                     uint8_t j = 5;
                                                                                                                                   while ( i + j < gsmS.rxCnt && gsmS.rxBuf[i + j] != ','  )//&& // Store until the next quote or end
                                                                                                                                   {

                                                                                                                                       EN.Key[n++] = gsmS.rxBuf[i + j];
                                                                                                                                       j++;


                                                                                                                                   }
                                                                                                                                   n=0;


                                                                                                                 }
                        else if(gsmS.rxBuf[i] == 'F' && gsmS.rxBuf[i+2] == 'U'  && gsmS.rxBuf[i+6] == ':'  ){//&&  gsmS.rxBuf[i+9] == '"'

                                                                                                                                           uint8_t j = 7;
                                                                                                                                                         while ( i + j < gsmS.rxCnt && gsmS.rxBuf[i + j] != ','  )//&& // Store until the next quote or end
                                                                                                                                                         {

                                                                                                                                                             EN.FWURL[n++] = gsmS.rxBuf[i + j];
                                                                                                                                                             j++;


                                                                                                                                                         }
                                                                                                                                                         n=0;


                                                                                                                                       }

                    }



                }
                MQTT_PubDelay = 0;

     }
//                if (strstr ((char*) gsmS.rxBuf, "RON"))
//                {
//                    R_IOPORT_PinWrite (&g_ioport_ctrl, RELAY, BSP_IO_LEVEL_HIGH);
//                    gpsS.relay = True;
//                    status = AT_Ok;
//                    UartPrintf ((uint8_t*) "Received RON\r\n", 14);
//                }
//                else if (strstr ((char*) gsmS.rxBuf, "ROFF"))
//                {
//                    R_IOPORT_PinWrite (&g_ioport_ctrl, RELAY, BSP_IO_LEVEL_LOW);
//                    gpsS.relay = False;
//                    status = AT_Ok;
//                    UartPrintf ((uint8_t*) "Received ROFF\r\n", 15);
//                }

            else if (strstr ((char*) gsmS.rxBuf, "GPIO_Setting"))
            {
                uint8_t i = 0;
                if (strstr ((char*) gsmS.rxBuf, "DOP"))
                {
                    for (i = 0; i < gsmS.rxCnt; i++)
                    {
                        if ((gsmS.rxBuf[i] == ',') && (gsmS.rxBuf[i + 1] == '"') && (gsmS.rxBuf[i + 2] == 'D')
                                && (gsmS.rxBuf[i + 4] == 'P'))
                        {
                            i += 5;
                            gpsS.DigitalOutput1 = (gsmS.rxBuf[i] - 0x30);
                            gpsS.DigitalOutput2 = (gsmS.rxBuf[i + 1] - 0x30);
                            gpsS.DigitalOutput3 = (gsmS.rxBuf[i + 2] - 0x30);
                            gpsS.DigitalOutput4 = (gsmS.rxBuf[i + 3] - 0x30);
                            break;
                        }
                    }
                    if (gpsS.DigitalOutput1)
                        R_IOPORT_PinWrite (&g_ioport_ctrl, BSP_IO_PORT_03_PIN_05, BSP_IO_LEVEL_HIGH);
                    else
                        R_IOPORT_PinWrite (&g_ioport_ctrl, BSP_IO_PORT_03_PIN_05, BSP_IO_LEVEL_LOW);
                    if (gpsS.DigitalOutput2)
                        R_IOPORT_PinWrite (&g_ioport_ctrl, BSP_IO_PORT_03_PIN_06, BSP_IO_LEVEL_HIGH);
                    else
                        R_IOPORT_PinWrite (&g_ioport_ctrl, BSP_IO_PORT_03_PIN_06, BSP_IO_LEVEL_LOW);
                    if (gpsS.DigitalOutput3)
                        R_IOPORT_PinWrite (&g_ioport_ctrl, BSP_IO_PORT_06_PIN_08, BSP_IO_LEVEL_HIGH);
                    else
                        R_IOPORT_PinWrite (&g_ioport_ctrl, BSP_IO_PORT_06_PIN_08, BSP_IO_LEVEL_LOW);
                    if (gpsS.DigitalOutput4)
                        R_IOPORT_PinWrite (&g_ioport_ctrl, BSP_IO_PORT_08_PIN_08, BSP_IO_LEVEL_HIGH);
                    else
                        R_IOPORT_PinWrite (&g_ioport_ctrl, BSP_IO_PORT_08_PIN_08, BSP_IO_LEVEL_LOW);

                    status = AT_Ok;
                   UartPrintf ((uint8_t*) "DigitalInput 12 Received\r\n", 26);
                }
                MQTT_PubDelay = 0;
//                else if(strstr((char *)gsmS.rxBuf, "BZON")) {
//                    R_IOPORT_PinWrite(&g_ioport_ctrl, BUZZER, BSP_IO_LEVEL_HIGH);
//                    gpsS.Buzzer = True;
//                    status = AT_Ok;
//
//                }else if(strstr((char *)gsmS.rxBuf, "BZOFF")) {
//                    R_IOPORT_PinWrite(&g_ioport_ctrl, BUZZER, BSP_IO_LEVEL_LOW);
//                    gpsS.Buzzer = False;
//                    status = AT_Ok;
//                }

            }
            else if (strstr ((char*) gsmS.rxBuf, "SUCC"))
            {
                status = AT_Ok;

            }
            else if (strstr ((char*) gsmS.rxBuf, "FAIL"))
            {
                status = AT_Error;
            }

        }
        else if (strstr ((char*) gsmS.rxBuf, "+MPUBEX:"))
        {
            if (strstr ((char*) gsmS.rxBuf, "SUCC"))
            {
                status = AT_Ok;
            }
            else
            {
                status = AT_Error;
            }

        }
        else if (strstr ((char*) gsmS.rxBuf, "+MQTT:"))
        {
            if (strstr ((char*) gsmS.rxBuf, "DISCONNECTED"))
            {
                gsmState = GSM_STATE_MQTTSTART;
                gsmS.Cmd = NETWORKREG_CMD_ADD + 1;
                status = AT_Busy;
            }

        }
        else if (strstr ((char*) gsmS.rxBuf, "+CPIN:"))
        {
            gsmState = GSM_STATE_TEST;
            status = AT_Ok;

        }
        else if (strstr ((char*) gsmS.rxBuf, "+MDISCONNECT:"))
        {
            if (strstr ((char*) gsmS.rxBuf, "SUCCESS"))
            {
                gsmState = GSM_STATE_MQTTSTART;
                gsmS.Cmd = NETWORKREG_CMD_ADD + 1;
                status = AT_Busy;
            }

        }
        else if (strstr ((char*) gsmS.rxBuf, "ERROR"))
       {
            status = AT_Error;

        }
        else if (strstr ((char*) gsmS.rxBuf, "+CCLK"))
        {


            int i = 0, n = 0;
            Bool_E DateFlag = False;
            Bool_E TimeFlag = False;


            for (i = 0; i <= gsmS.rxCnt; i++)
            {
                if (DateFlag)
                {
                    IOT.Date[n++] = gsmS.rxBuf[i];
                    if (gsmS.rxBuf[i + 1] == ',')
                    {

                        IOT.Date[n] = '\0'; // Null-terminate the date string



                         //y= 2000 + atoi(&gpsS.Date[0]);
                         //m = atoi(&gpsS.Date[3]);
                         //d = atoi(&gpsS.Date[6]);
                        DateFlag = False;
                        TimeFlag = True;
                        n = 0;
                        i +=1;

                        UartPrintf ((uint8_t*) IOT.Date, 11);

                    }
                }
                else if (TimeFlag)
                {
                    IOT.Time[n++] = gsmS.rxBuf[i];
                    if (gsmS.rxBuf[i + 1] == '+')
                    {
                        IOT.Time[n] = '\0';

                        //h = atoi(&gpsS.Time[0]);
                        //mi = atoi(&gpsS.Time[3]);
                        //s = atoi(&gpsS.Time[6]);

                        UartPrintf ((uint8_t*) IOT.Time, 11);

                        break;
                    }
                }else{

                    if ((gsmS.rxBuf[i] == '+') && (gsmS.rxBuf[i + 5] == ':') && gsmS.rxBuf[i + 7] == '"')
                    {
                        status = AT_Ok;
                        i += 7;
                        DateFlag = True;
                    }
                    else
                    {
                        status = AT_Busy;
                    }

            }
            }
            epoch = convertToEpoch(IOT.Date, IOT.Time);
            sprintf(IOT.etime, "%lu", epoch);
  }


        else if (gsmState == GSM_STATE_GPSENABLE)
              {
                  if (strstr ((char*) gsmS.rxBuf, "OK"))
                  {
                      status = AT_Ok;
                  }
              }






        else if (gsmState == GSM_STATE_GPSGETENABLE)
        {
            uint8_t i = 0, n = 0;
            Bool_E SatFlag = False;
            Bool_E HdopFlag = False;
          //  Bool_E AltFlag = False;

            if (strstr ((char*) gsmS.rxBuf, "$GNGGA"))
                      {
            for (i = 0; i <= gsmS.rxCnt; i++) {

                 if (SatFlag) {
                    IOT.satellites[n++] = gsmS.rxBuf[i];
                    if (gsmS.rxBuf[i + 1] == ',') {
                        //gpsS.satellites[n] = '\0';  // Null-terminate string
                        HdopFlag = True;
                        SatFlag = False;
                        UartPrintf((uint8_t*)IOT.satellites, 6);  // Print number of satellites
                        i += 1;
                        n = 0;
                    }
                }
                else if (HdopFlag) {  // Parsing HDOP value
                    IOT.hdop[n++] = gsmS.rxBuf[i];
                    if (gsmS.rxBuf[i + 1] == ',') {
                      //  gpsS.hdop[n] = '\0';  // Null-terminate string
                      //  AltFlag = True;
                     //   HdopFlag = False;
                        UartPrintf((uint8_t*)IOT.hdop,6);  // Print HDOP
                        break;
                       // i += 1;
                       // n = 0;
                    }
                }
               // else if (AltFlag) {  // Parsing Altitude
               //     IOT.altitude[n++] = gsmS.rxBuf[i];
                //    if (gsmS.rxBuf[i + 1] == ',') {
                        //gpsS.altitude[n] = '\0';  // Null-terminate string
                //        UartPrintf((uint8_t*)IOT.altitude, 6);  // Print altitude
                 //       break;  // Exit once Altitude is captured
                 //   }
              //  }
                else {
                    if ((gsmS.rxBuf[i] == '$') && (gsmS.rxBuf[i+17] == ',')&&(gsmS.rxBuf[i + 47] == '1')) {  // Fix Quality (1 = GPS fix)
                        status = AT_Ok;
                        SatFlag = True;  // Start Latitude parsing
                        i += 48;  // Skip to Latitude field (second field)
                    }
                    else if ((gsmS.rxBuf[i] == '$') && (gsmS.rxBuf[i+17] == ',') && (gsmS.rxBuf[i + 22] == '0')) {  // Fix Quality 0 (no fix)
                        status = AT_Ok;  // No valid GPS fix
                    }
                }
            }
        }
    }else if (gsmState == GSM_STATE_GPSNETENABLE)
    {
        if (strstr ((char*) gsmS.rxBuf, "$GNRMC"))
                {
                    uint8_t i = 0, n = 0;
                    Bool_E LatFlag = False;
                    Bool_E LonFlag = False;
                    Bool_E SpeedFlag = False;
                    Bool_E cogflag=False;
                    for (i = 0; i <= gsmS.rxCnt; i++)
                    {
                        if (LatFlag)
                        {
                            IOT.Latitude[n++] = gsmS.rxBuf[i];
                            if (gsmS.rxBuf[i + 1] == ',')
                            {
                                LonFlag = True;
                                LatFlag = False;
                                i += 3;
                                n = 0;
                                UartPrintf ((uint8_t*) IOT.Latitude, 12);
                            }

                        }
                        else if (LonFlag)
                        {
                            IOT.Longitude[n++] = gsmS.rxBuf[i];
                            if (gsmS.rxBuf[i + 1] == ',')
                            {
                                SpeedFlag = True;
                                LonFlag=False;
                                UartPrintf ((uint8_t*) IOT.Longitude, 12);
                                i += 3;
                                n = 0;

                            }

                        }

                        else if (SpeedFlag)  // Speed
                                                  {
                                                      IOT.speed[n++] = gsmS.rxBuf[i];
                                                      if (gsmS.rxBuf[i + 1] == ',')
                                                      {

                                                        SpeedFlag = False;
                                                        cogflag=True;

                                                          UartPrintf((uint8_t*)IOT.speed, 6);
                                                          i+=1;
                                                          n=0;
                                                      }
                                                  }
                        else if (cogflag)  // cog
                                                  {
                                                   IOT.cog[n++] = gsmS.rxBuf[i];
                                                   if (gsmS.rxBuf[i + 1] == ',')
                                                    {
                                                     UartPrintf((uint8_t*)IOT.cog, 5);
                                                            break;
                                                         }
                                          }
                        else
                        {
                            if ((gsmS.rxBuf[i] == '$') && (gsmS.rxBuf[i + 18] == 'A') && (gsmS.rxBuf[i + 32] == 'N')
                                    && (gsmS.rxBuf[i + 47] == 'E'))
                            {
                                status = AT_Ok;
                                i += 19;
                               LatFlag = True;

                            }
                            else if ((gsmS.rxBuf[i] == '$') && gsmS.rxBuf[i + 18] == 'V')
                            {
                                status = AT_Ok;   //AT_Busy;
                            }
                        }
                    }

                }


                if (prev_lat != 0.0 && prev_lon != 0.0) {
      double cur_lat = convertToDecimalDegrees(atof((char*) IOT.Latitude));  // Convert DM to DD
      double cur_lon = convertToDecimalDegrees(atof((char*) IOT.Longitude)); // Convert DM to DD

      double distance = haversine(prev_lat, prev_lon, cur_lat, cur_lon);
      total_distance_km += distance; // Update total distance
                                   }

          // Update previous coordinates
          prev_lat = convertToDecimalDegrees(atof((char*) IOT.Latitude));
          prev_lon = convertToDecimalDegrees(atof((char*) IOT.Longitude));

    }
        else
        {
            status = AT_Busy;
        }
    }


//    UartPrintf();
 // debugPrintf((uint8_t *)gsmS.rxBuf, gsmS.rxCnt);
    memset ((char*) gsmS.rxBuf, 0, gsmS.rxCnt);
    gsmS.rxFlag = False;
    gsmS.rxCnt = 0;
    return status;
}

/**
 * @brief  Gsm_responseComplete shall Check the response
 * @param  timeout
 * @retval Status_E
 */
static Status_E Gsm_responseComplete(uint32_t timeout)
{
    static bool timeoutFlag = false;
    /* Check data | response received from server */
    if (gsmS.rxFlag == True)
    {
        timeoutFlag = false;
        return Gsm_rxFrameHandle ();
    }

    if (timeoutFlag == false)
    {
        gsmS.timeCnt = (uint16_t) timeout;
        timeoutFlag = true;

    }
    else
    {
        if (gsmS.timeCnt <= 0)
        {
            timeoutFlag = False;
            return AT_Timeout;
        }
    }
    return AT_Busy;
}





    // Start the RTC
   // R_RTC_Start(&g_rtc_ctrl);


/**
 * @brief Gsm Polling process will handle all the recieve and send
 to through GSM. This function should call in loop
 * @param  none
 * @retval none
 */
void Gsm_PollingProcess(void)
{
    static Substatus_E gsmSubstate;
    Status_E Status = AT_Busy;
    static uint8_t retryCnt = 10;

    switch (gsmState)
    {
        case GSM_STATE_TEST:
            if (gsmSubstate == Cmd_Send)
            {
                Gsm_SendCmd ((uint8_t*) atCmd[2], (uint16_t) strlen ((char*) atCmd[2]));
                gsmSubstate = Cmd_Waiting;

            }
            else
            {
                Status = Gsm_responseComplete (GSM_TIMEOUT);
                if (Status == AT_Timeout)
                {
                    retryCnt--;
                    gsmSubstate = Cmd_Send;
                    if (retryCnt == 0)
                    {
                        retryCnt = 10;
                    }
                }
                else if (Status == AT_Ok)
                {
                    gsmS.Cmd = 3;
                    gsmState = GSM_STATE_INIT;
                    gsmSubstate = Cmd_Send;
                }
            }
        break;

        case GSM_STATE_RESET:
            IS_Indication = false;
            Previous_IS = Current_IS;
            BootSend  = true;
            if (gsmSubstate == Cmd_Send)
            {
                Gsm_SendCmd ((uint8_t*) atCmd[1], (uint16_t) strlen ((char*) atCmd[1]));

                R_IOPORT_PinWrite (&g_ioport_ctrl, PWRKEY_4G, BSP_IO_LEVEL_HIGH);
                //              R_IOPORT_PinWrite(&g_ioport_ctrl, Reset_4G, BSP_IO_LEVEL_HIGH);
                //              R_IOPORT_PinWrite(&g_ioport_ctrl, PWRKEY_4G, BSP_IO_LEVEL_LOW);
                Delay_MilliSec (10);
                R_IOPORT_PinWrite (&g_ioport_ctrl, Reset_4G, BSP_IO_LEVEL_LOW);
                gsmSubstate = Cmd_Waiting;

            }
            else
            {
                Status = Gsm_responseComplete (GSM_REBOOT_TIMEOUT);
                if (Status == AT_Timeout)
                {
                    gsmSubstate = Cmd_Send;
                    gsmState = GSM_STATE_TEST;
                }
            }
        break;

        case GSM_STATE_INIT:
            if (gsmSubstate == Cmd_Send)
            {
                Gsm_SendCmd ((uint8_t*) atCmd[gsmS.Cmd], (uint16_t) strlen ((char*) atCmd[gsmS.Cmd]));
                gsmSubstate = Cmd_Waiting;

            }
            else
            {
                Status = Gsm_responseComplete (GSM_TIMEOUT);
                if ((Status == AT_Timeout))
                {
                    gsmSubstate = Cmd_Send;
                    retryCnt--;
                }
                else if (Status == AT_Ok)
                {
                    gsmSubstate = Cmd_Send;
                    gsmS.Cmd += 1;
                    retryCnt = 10;
                    if (gsmS.Cmd >= INIT_CMD_ADD)
                    {
                        gsmState = GSM_STATE_NETWORKREG;
                    }
                }
            }
        break;

        case GSM_STATE_NETWORKREG:
            if (gsmSubstate == Cmd_Send)
            {
                Gsm_SendCmd ((uint8_t*) atCmd[gsmS.Cmd], (uint16_t) strlen ((char*) atCmd[gsmS.Cmd]));

                gsmSubstate = Cmd_Waiting;

            }
            else
            {
                Status = Gsm_responseComplete (GSM_NTWK_TIMEOUT);
                if (Status == AT_Timeout)
                {
                    gsmSubstate = Cmd_Send;
                    retryCnt--;
                }
                else if (Status == AT_Ok)
                {
                    imeiStart=True;
                    gsmSubstate = Cmd_Send;
                    gsmS.Cmd += 1;
                    retryCnt = 10;
                    if (gsmS.Cmd >= NETWORKREG_CMD_ADD)
                    {
                        gsmState = GSM_STATE_MQTTSTART;
                    }
                }
            }
        break;

        case GSM_STATE_MQTTSTART:
            if (gsmSubstate == Cmd_Send)
            {
                Gsm_SendCmd ((uint8_t*) atCmd[gsmS.Cmd], (uint16_t) strlen ((char*) atCmd[gsmS.Cmd]));
                gsmSubstate = Cmd_Waiting;

            }
            else
            {
                Status = Gsm_responseComplete (GSM_NTWK_TIMEOUT);
                if (Status == AT_Timeout)
                {
                    gsmSubstate = Cmd_Send;
                    retryCnt--;
                }
                else if (Status == AT_Ok)
                {
                    gsmSubstate = Cmd_Send;
                    gsmS.Cmd += 1;
                    retryCnt = 3;
                    if (gsmS.Cmd >= MQTTSTART_CMD_ADD)
                    {
                        gsmState = GSM_STATE_MQTTSUB;
                    }
                }
            }
        break;

        case GSM_STATE_MQTTSUB:
            if (gsmSubstate == Cmd_Send)
            {
                Gsm_SendCmd ((uint8_t*) atCmd[gsmS.Cmd], (uint16_t) strlen ((char*) atCmd[gsmS.Cmd]));
                gsmSubstate = Cmd_Waiting;

            }
            else
            {
                Status = Gsm_responseComplete (GSM_NTWK_TIMEOUT);
                if (Status == AT_Timeout)
                {
                    gsmSubstate = Cmd_Send;
                    retryCnt--;
                }
                else if (Status == AT_Ok)
                {
                    gsmSubstate = Cmd_Send;
                    gsmS.Cmd += 1;
                    retryCnt = 3;
                    if (gsmS.Cmd >= MQTTSEND_CMD_ADD)
                    {
                        gsmState = GSM_STATE_GPSENABLE;
                    }
                }
            }
        break;

        case GSM_STATE_MQTTPUB:
            if (gsmSubstate == Cmd_Send)
            {
                uint16_t len = 0;
                char Ptr[80] =
                { 0 };

                Gsm_PrepareMQTTtxpayload ();

                if( (IS_event_send) && (Eventstate >= SET_IOT_Settings) && (Eventstate <=Ignition_OFF) )
                {

                    IS_event_send = false;
                    islive=True;
                    len = sprintf (Ptr, "%s,%u\r\n", Event_Pub, (uint16_t) strlen ((char*) mqttPayload));
                    Eventstate = Default;
                }
                else if(BootSend && Eventstate == Bootnotification)
                {

                    BootSend  = false;
                    IS_Indication = true;
                    islive=True;
                    len = sprintf (Ptr, "%s,%u\r\n", Event_Pub, (uint16_t) strlen ((char*) mqttPayload));

                }

                else
                {

                    islive=True;
                    len = sprintf (Ptr, "%s,%u\r\n", atCmd[MQTTSEND_CMD_ADD], (uint16_t) strlen ((char*) mqttPayload));

                }
                Eventstate = Default;
                MQTT_PubDelay = MQTT_PUBLISH_DELAY;
                Gsm_SendCmd ((uint8_t*) Ptr, (uint16_t) len);
                gsmSubstate = Cmd_Waiting;

            }
            else
            {
                Status = Gsm_responseComplete (GSM_MQTT_RES_WAITTIME);
                if ((Status == AT_Timeout) || (Status == AT_Ok))
                {
                    Gsm_SendCmd ((uint8_t*) mqttPayload, (uint16_t) strlen ((char*) mqttPayload));
                    gsmSubstate = Cmd_Send;
                    gsmState = GSM_STATE_MQTTIDLE;
                }
            }
        break;

        case GSM_STATE_MQTTIDLE:
            if ((MQTT_PubDelay == 0U) && (gsmS.rxEnd != True))
            {
                gsmS.Cmd = MQTTSEND_CMD_ADD + 1;
                gsmState = GSM_STATE_GETCLOCK;
            }
            if (gsmS.rxFlag == True)
            {
           Status = Gsm_rxFrameHandle ();
            }
        break;

        case GSM_STATE_MQTTDISCONNECT:
            Gsm_SendCmd ((uint8_t*) atCmd[22], (uint16_t) strlen ((char*) atCmd[22]));
            gsmSubstate = Cmd_Send;
            IS_Indication = false;
            gsmState = GSM_STATE_RESET;

        break;

        case GSM_STATE_GETCLOCK:
            if (gsmSubstate == Cmd_Send)
            {
                Gsm_SendCmd ((uint8_t*) atCmd[23], (uint16_t) strlen ((char*) atCmd[23]));
                gsmSubstate = Cmd_Waiting;

            }
            else
            {
                Status = Gsm_responseComplete (GSM_GPS_TIMEOUT);
                if (Status == AT_Timeout)
                {
                    gsmSubstate = Cmd_Send;
                    retryCnt--;
                }
                else if (Status == AT_Ok)
                {
                    gsmSubstate = Cmd_Send;
                    retryCnt = 5;
                    gsmState = GSM_STATE_GPSGETENABLE;
                }
            }
        break;

        case GSM_STATE_GPSENABLE://GSM_STATE_GPSGETENABLE
            if (gsmSubstate == Cmd_Send)
            {
                Gsm_SendCmd ((uint8_t*) atCmd[24], (uint16_t) strlen ((char*) atCmd[24]));
                gsmSubstate = Cmd_Waiting;

            }
            else
            {
                Status = Gsm_responseComplete (GSM_GPS_TIMEOUT);
                if (Status == AT_Timeout)
                {
                    gsmSubstate = Cmd_Send;
                    retryCnt--;
                }
                else if (Status == AT_Ok)
                {
                    gsmSubstate = Cmd_Send;
                    retryCnt = 5;
                    gsmState = GSM_STATE_GETCLOCK;

                }
            }
        break;

        case GSM_STATE_GPSGETENABLE:
            if (gsmSubstate == Cmd_Send)
            {
                Gsm_SendCmd ((uint8_t*) atCmd[25], (uint16_t) strlen ((char*) atCmd[25]));
                gsmSubstate = Cmd_Waiting;

            }
            else
            {
                Status = Gsm_responseComplete (GSM_GPS_TIMEOUT);
                if (Status == AT_Timeout)
                {
                    gsmSubstate = Cmd_Send;
                    retryCnt--;
                }
                else if (Status == AT_Ok)
                {
                    gsmSubstate = Cmd_Send;
                   gsmS.Cmd += 1;
                    retryCnt = 5;
                    gsmState =GSM_STATE_GPSNETENABLE;

                }
            }
            break;
        case GSM_STATE_GPSNETENABLE:
                            if (gsmSubstate == Cmd_Send) {
                                // Send the command to get the GNGSA sentence (24th command in atCmd array assumed)
                                Gsm_SendCmd((uint8_t*)atCmd[26], (uint16_t)strlen((char*)atCmd[26]));
                                gsmSubstate = Cmd_Waiting;
                            } else {
                                Status = Gsm_responseComplete(GSM_GPS_TIMEOUT);
                                if (Status == AT_Timeout) {
                                    gsmSubstate = Cmd_Send;
                                    retryCnt--;
                                } else if (Status == AT_Ok) {


                                    gsmSubstate = Cmd_Send;
                                    gsmS.Cmd += 1;
                                    retryCnt = 5;
                                    gsmState = GSM_STATE_MQTTPUB;
                                }
                            }
                            break;
            /*




            /* case GSM_STATE_GPSDISABLE:
             if(gsmSubstate == Cmd_Send) {
             Gsm_SendCmd((uint8_t *)atCmd[gsmS.Cmd], (uint16_t)strlen((char *)atCmd[gsmS.Cmd]));
             gsmSubstate = Cmd_Waiting;

             }else {
             Status = Gsm_responseComplete(GSM_GPS_TIMEOUT);
             if(Status == AT_Timeout) {
             gsmSubstate = Cmd_Send;
             retryCnt--;
             }else if(Status == AT_Ok) {
             gsmSubstate = Cmd_Send;
             // gsmS.Cmd += 1;
             retryCnt = 10;
             if(gsmS.Cmd >= GPS_GET_CMD_ADD) {
             gsmState = GSM_STATE_RESET;
             }
             }
             }
             break;
             void Odometer_value(void){
    if (prev_lat != 0.0 && prev_lon != 0.0) {
                             double cur_lat = atof((char*) IOT.Latitude);
                             double cur_lon = atof((char*) IOT.Longitude);

                             double distance = haversine(prev_lat, prev_lon, cur_lat, cur_lon);
                             total =total+ distance; // Update total distance

                           //  printf("Odometer: %.2f km\n", total_distance_km);

                         }

                         // Update previous coordinates
                         prev_lat = atof((char*) IOT.Latitude);
                         prev_lon = atof((char*) IOT.Longitude);


}
             */
        default:
            gsmState = GSM_STATE_RESET;
            gsmSubstate = Cmd_Send;
        break;
    }


    if ((Status == AT_Error) || (retryCnt == 0U))
    {
        gsmState = GSM_STATE_RESET;
        retryCnt = 10;
        gsmSubstate = Cmd_Send;
    }

    if((IS_Indication) && (Previous_IS != Current_IS))
    {
        Previous_IS = Current_IS;
//        memset ((char*) mqttPayload, 0, MQTT_BUF_SIZE);
        if(Current_IS == True)
        {
            Eventstate = Ignition_ON;

        }
        else if(Current_IS == False)
        {
            Eventstate = Ignition_OFF;

        }


    }

}

/**
 * @brief Gsm rx Callback Function
 * @param  rxByte received Byte
 * @retval none
 */
void Gsm_rxCallback(uint8_t rxByte)
{
    gsmS.rxBuf[gsmS.rxCnt++] = rxByte;
    gsmS.rxEnd = True;
    gsmS.rxDelay = GSM_RX_WAITTIME;

    if (gsmS.rxCnt >= RX_BUF_MAX_CNT)
    {
        gsmS.rxCnt = 0;
        gsmS.rxFlag = True;
    }
}

/**
 * @brief Gsm timer Callback Function
 * @param  none
 * @retval none
 */
void Gsm_timer1MSCallback(void)
{
    if ((gsmS.rxEnd == true) && (gsmS.rxDelay != 0U))
    {
        gsmS.rxDelay--;
        if (!gsmS.rxDelay)
        {
            gsmS.rxFlag = True;
            gsmS.rxEnd = False;
        }
    }

    if (gsmS.timeCnt != 0U)
    {
        gsmS.timeCnt--;
    }
    if (MQTT_PubDelay != 0U)
    {
        MQTT_PubDelay--;
    }
}
/*********************************END OF FILE*********************************/
