/*
 * gsmCmd.h
 *
 *  Created on: Mar 23, 2021
 *      Author: yoganathan.v
 */

/* Define to prevent recursive inclusion -----------------------------*/
#ifndef INC_GSMCMD_H_
#define INC_GSMCMD_H_

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ----------------------------------------------------------*/
#include "string.h"


/* Define ------------------------------------------------------------*/

/* Macro -------------------------------------------------------------*/
#define INIT_CMD_ADD			8
#define NETWORKREG_CMD_ADD		16
#define MQTTSTART_CMD_ADD		19
#define MQTTSEND_CMD_ADD        21
#define GPS_ENABLE_CMD_ADD      25
#define GPS_GET_CMD_ADD         26

char Relay_Sub[28] = {0};
char Gpio_Sub[50] = {0};
char Module_Pub[38] = {0};
char Event_Pub[50] = {0};

/* Typedef -----------------------------------------------------------*/
char* atCmd[] =
{
    "\r\n",                                                //0
    "AT+RESET\r\n",                                        //1
    "ATE0\r\n",                                            //2
    "AT\r\n",                                              //3
    "AT+CSQ\r\n",                                          //4
    "AT+CMGF=1\r\n",                                       //5
    "AT+CSCS=\"GSM\"\r\n",                                 //6
    "AT+COPS?\r\n",                                        //7
    "AT+CPIN?\r\n",                                        //8
    "AT+CEREG?\r\n",                                       //9
    "AT+CIMI\r\n"  ,                                       //10
    "ATI\r\n",                                          //11
    "AT+CGQREQ?\r\n",                                      //12
    "AT+CGATT?\r\n",                                       //13
    "AT+CGQMIN?\r\n",                                      //14
    "AT+MCONFIG=\"AT-COMMANDS\",\"1\",\"1\"\r\n",          //15
    "AT+NETOPEN\r\n",                                      //16
    "AT+MIPSTART=122.166.210.142,1883\r\n",
  //"AT+MIPSTART=broker.mqttdashboard.com,1883\r\n",       //17
    "AT+MCONNECT=1,30\r\n",                                //18
    (char*)&Relay_Sub[0],                                  //19   //OTA Topic
    (char*)&Gpio_Sub[0],                                   //20
    (char*)&Module_Pub[0],                                 //21  //IOT Stream
   //(char*)&Event_Pub[0],
    "AT+MDISCONNECT\r\n",                                   //22
    "AT+CCLK?\r\n",                                        //23
    "AT+MGPSC=1\r\n",                                      //24
    "AT+GETGPS=GNGGA,1\r\n",                               //25
    "AT+GETGPS=GNRMC,1\r\n",                               //26
  // "AT+GETGPS=GNGSA,1\r\n",
//    "AT+GETGPS=GNRMC,0\r\n",                               //25
  //  "AT+MGPSC=0\r\n",                                      //26

};

/* Variables ---------------------------------------------------------*/

/* Function prototypes -----------------------------------------------*/

#ifdef __cplusplus
}
#endif
#endif /* INC_GSMCMD_H_ */
