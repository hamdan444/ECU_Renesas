/*
 * CurrentSens.c
 *
 *  Created on: 06-Mar-2023
 *      Author: Admin
 */

#include "CurrentSens.h"


CurrentSensor_Handle_S IsenS    = {0};

uint8_t IAmps[5] = {0};

bsp_io_level_t  Button1Status;
bsp_io_level_t  Button2Status;
bsp_io_level_t  Button3Status;
bsp_io_level_t  Button4Status;

/**
  * @brief Current Sensor Uart rx Callback Function
  * @param  rxByte received Byte
  * @retval none
  */
void CurrentSense_rxCallback(uint8_t rxByte)
{
    IsenS.rxBuf[IsenS.rxCnt++] = rxByte;
    if(rxByte == 0x0A)/* && (IsenS.rxBuf[IsenS.rxCnt-1] == 0x0D )*/ {
        IsenS.rxFlag = True;
    }
    if(IsenS.rxCnt >= I_RX_BUF_SIZE) {
        gsmS.rxCnt = 0;
    }
}

void Gpio_InputCheck(void)
{
    R_IOPORT_PinRead(&g_ioport_ctrl, SEAT_OPEN_MCU_2,&Button1Status); /*  Seat Open MCU  */
    if(Button1Status == BSP_IO_LEVEL_HIGH) {
        gpsS.DigitalInput1 = True;
    }else {
        gpsS.DigitalInput1 = False;
    }

    R_IOPORT_PinRead(&g_ioport_ctrl, BAT_REMOVE_MCU_2,&Button2Status); /*  BAT Removal  */
    if(Button2Status == BSP_IO_LEVEL_HIGH) {
        gpsS.DigitalInput2 = True;
    }else {
        gpsS.DigitalInput2 = False;
    }
    R_IOPORT_PinRead(&g_ioport_ctrl, BSP_IO_PORT_00_PIN_12,&Button3Status); /*  Brake  */
    if(Button3Status == BSP_IO_LEVEL_HIGH) {
        gpsS.DigitalInput3 = True;
    }else {
        gpsS.DigitalInput3 = False;
    }

    R_IOPORT_PinRead(&g_ioport_ctrl, IGNITION_SWITCH,&Button4Status); /*  Ignition Switch  */
    if(Button4Status == BSP_IO_LEVEL_HIGH) {
        gpsS.DigitalInput4 = True;
        Current_IS = gpsS.DigitalInput4;
    }else {
        gpsS.DigitalInput4 = False;
        Current_IS = gpsS.DigitalInput4;
    }
}

void CurrentSense_RxFrameHandle(void)
{
    uint16_t i = 0;
    if( IsenS.rxFlag)
    {

        for(i=1; i<=(IsenS.rxCnt-3); i++)
        {
            IAmps[i-1] = IsenS.rxBuf[i];
        }

//        n = 0;
//        Current = 0;
////        while(IAmps[n] != 0)
//        for(n = 0; n < 5; n++)
//        {
//            Current = ((Current*10)+ (IAmps[n] - 0x30));
////            n++;
//        }
//        Current_Amps = ((float)Current / 1000);


        memset((char *)IsenS.rxBuf,0,IsenS.rxCnt);
        IsenS.rxCnt = 0;
        IsenS.rxFlag = False;

    }

}

